# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'comeFdqjTP.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import icons_rc

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(1356, 880)
        self.widget = QWidget(Form)
        self.widget.setObjectName(u"widget")
        self.widget.setGeometry(QRect(0, 80, 541, 201))
        self.verticalLayout = QVBoxLayout(self.widget)
        self.verticalLayout.setSpacing(5)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(5, 5, 5, 5)
        self.stackedWidget = QStackedWidget(self.widget)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.page = QWidget()
        self.page.setObjectName(u"page")
        self.stackedWidget.addWidget(self.page)
        self.page_2 = QWidget()
        self.page_2.setObjectName(u"page_2")
        self.stackedWidget.addWidget(self.page_2)

        self.verticalLayout.addWidget(self.stackedWidget)

        # self.pushButton = QPushButton(Form)
        # self.pushButton.setObjectName(u"pushButton")
        # self.pushButton.setGeometry(QRect(500, 540, 151, 131))
        # icon = QIcon()
        # icon.addFile(u":/newPrefix/r.png", QSize(), QIcon.Normal, QIcon.Off)
        # self.pushButton.setIcon(icon)
        # self.pushButton.setIconSize(QSize(160, 203))
        self.lineEdit = QLineEdit(Form)
        self.lineEdit.setObjectName(u"lineEdit")
        self.lineEdit.setGeometry(QRect(120, 20, 241, 41))
        self.lineEdit.setStyleSheet(u"QLineEdit{\n"
"	background-color:rgb(27,27,27);\n"
"	border-radius:12px;\n"
"	color:rgb(240,240,240);\n"
"	padding-left:15px;\n"
"	border: 1px solid rgba(255, 255, 255, 50);\n"
"	font: 24pt \"Agency FB\";\n"
"}\n"
"QLineEdit:focus{\n"
"	border: 1px solid rgba(99, 173, 229, 150);\n"
"}")
        self.widget_2 = QWidget(Form)
        self.widget_2.setObjectName(u"widget_2")
        self.widget_2.setGeometry(QRect(640, 80, 481, 191))
        self.verticalLayout_2 = QVBoxLayout(self.widget_2)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.stackedWidget_2 = QStackedWidget(self.widget_2)
        self.stackedWidget_2.setObjectName(u"stackedWidget_2")
        self.page_3 = QWidget()
        self.page_3.setObjectName(u"page_3")
        self.stackedWidget_2.addWidget(self.page_3)
        self.page_4 = QWidget()
        self.page_4.setObjectName(u"page_4")
        self.stackedWidget_2.addWidget(self.page_4)

        self.verticalLayout_2.addWidget(self.stackedWidget_2)

        self.widget_3 = QWidget(Form)
        self.widget_3.setObjectName(u"widget_3")
        self.widget_3.setGeometry(QRect(10, 333, 531, 201))
        self.verticalLayout_3 = QVBoxLayout(self.widget_3)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.stackedWidget_3 = QStackedWidget(self.widget_3)
        self.stackedWidget_3.setObjectName(u"stackedWidget_3")
        self.page_5 = QWidget()
        self.page_5.setObjectName(u"page_5")
        self.stackedWidget_3.addWidget(self.page_5)
        self.page_6 = QWidget()
        self.page_6.setObjectName(u"page_6")
        self.stackedWidget_3.addWidget(self.page_6)

        self.verticalLayout_3.addWidget(self.stackedWidget_3)

        self.widget_4 = QWidget(Form)
        self.widget_4.setObjectName(u"widget_4")
        self.widget_4.setGeometry(QRect(640, 343, 481, 191))
        self.verticalLayout_4 = QVBoxLayout(self.widget_4)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.stackedWidget_4 = QStackedWidget(self.widget_4)
        self.stackedWidget_4.setObjectName(u"stackedWidget_4")
        self.page_7 = QWidget()
        self.page_7.setObjectName(u"page_7")
        self.stackedWidget_4.addWidget(self.page_7)
        self.page_8 = QWidget()
        self.page_8.setObjectName(u"page_8")
        self.stackedWidget_4.addWidget(self.page_8)

        self.verticalLayout_4.addWidget(self.stackedWidget_4)

        self.pushButton_2 = QPushButton(Form)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(500, 690, 151, 131))
        icon1 = QIcon()
        icon1.addFile(u":/newPrefix/d.png", QSize(), QIcon.Normal, QIcon.Off)
        self.pushButton_2.setIcon(icon1)
        self.pushButton_2.setIconSize(QSize(130, 150))
        self.lineEdit_5 = QLineEdit(Form)
        self.lineEdit_5.setObjectName(u"lineEdit_5")
        self.lineEdit_5.setGeometry(QRect(730, 20, 331, 41))
        self.lineEdit_5.setStyleSheet(u"QLineEdit{\n"
"	background-color:rgb(27,27,27);\n"
"	border-radius:12px;\n"
"	color:rgb(240,240,240);\n"
"	padding-left:15px;\n"
"	border: 1px solid rgba(255, 255, 255, 50);\n"
"	font: 24pt \"Agency FB\";\n"
"}\n"
"QLineEdit:focus{\n"
"	border: 1px solid rgba(99, 173, 229, 150);\n"
"}")
        self.lineEdit_2 = QLineEdit(Form)
        self.lineEdit_2.setObjectName(u"lineEdit_2")
        self.lineEdit_2.setGeometry(QRect(100, 280, 291, 41))
        self.lineEdit_2.setStyleSheet(u"QLineEdit{\n"
"	background-color:rgb(27,27,27);\n"
"	border-radius:12px;\n"
"	color:rgb(240,240,240);\n"
"	padding-left:15px;\n"
"	border: 1px solid rgba(255, 255, 255, 50);\n"
"	font: 24pt \"Agency FB\";\n"
"}\n"
"QLineEdit:focus{\n"
"	border: 1px solid rgba(99, 173, 229, 150);\n"
"}")
        self.lineEdit_3 = QLineEdit(Form)
        self.lineEdit_3.setObjectName(u"lineEdit_3")
        self.lineEdit_3.setGeometry(QRect(730, 280, 361, 41))
        self.lineEdit_3.setStyleSheet(u"QLineEdit{\n"
"	background-color:rgb(27,27,27);\n"
"	border-radius:12px;\n"
"	color:rgb(240,240,240);\n"
"	padding-left:15px;\n"
"	border: 1px solid rgba(255, 255, 255, 50);\n"
"	font: 24pt \"Agency FB\";\n"
"}\n"
"QLineEdit:focus{\n"
"	border: 1px solid rgba(99, 173, 229, 150);\n"
"}")
#         self.pushButton_3 = QPushButton(Form)
#         self.pushButton_3.setGeometry(QRect(1150, 800, 201, 71))
#         self.pushButton_3.setStyleSheet("QPushButton\n"
# "{\n"
# "    background-color:rgb(27,27,27);\n"
# "    border-radius:12px;\n"
# "    color:rgb(240,240,240);\n"
# "    padding-left:15px;\n"
# "    border: 1px solid rgba(255, 255, 255, 50);\n"
# "    font: 24pt \"Agency FB\";\n"
# "}\n"
# "QPushButton:focus{\n"
# "    border: 1px solid rgba(99, 173, 229, 150);\n"
# "}")
#         self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_4 = QPushButton(Form)
        self.pushButton_4.setGeometry(QRect(970, 740, 381, 61))
        self.pushButton_4.setStyleSheet("QPushButton\n"
"{\n"
"    background-color:rgb(27,27,27);\n"
"    border-radius:12px;\n"
"    color:rgb(240,240,240);\n"
"    padding-left:15px;\n"
"    border: 1px solid rgba(255, 255, 255, 50);\n"
"    font: 24pt \"Agency FB\";\n"
"}\n"
"QPushButton:focus{\n"
"    border: 1px solid rgba(99, 173, 229, 150);\n"
"}")
        self.pushButton_4.setObjectName("pushButton_4")
        self.pushButton_5 = QPushButton(Form)
        self.pushButton_5.setGeometry(QRect(970, 680, 381, 61))
        self.pushButton_5.setStyleSheet("QPushButton\n"
"{\n"
"    background-color:rgb(27,27,27);\n"
"    border-radius:12px;\n"
"    color:rgb(240,240,240);\n"
"    padding-left:15px;\n"
"    border: 1px solid rgba(255, 255, 255, 50);\n"
"    font: 24pt \"Agency FB\";\n"
"}\n"
"QPushButton:focus{\n"
"    border: 1px solid rgba(99, 173, 229, 150);\n"
"}")
        self.pushButton_5.setObjectName("pushButton_5")
        self.pushButton_6 = QPushButton(Form)
        self.pushButton_6.setGeometry(QRect(970, 620, 381, 61))
        self.pushButton_6.setStyleSheet("QPushButton\n"
"{\n"
"    background-color:rgb(27,27,27);\n"
"    border-radius:12px;\n"
"    color:rgb(240,240,240);\n"
"    padding-left:15px;\n"
"    border: 1px solid rgba(255, 255, 255, 50);\n"
"    font: 24pt \"Agency FB\";\n"
"}\n"
"QPushButton:focus{\n"
"    border: 1px solid rgba(99, 173, 229, 150);\n"
"}")
        self.pushButton_6.setObjectName("pushButton_6")
        self.pushButton_7 = QPushButton(Form)
        self.pushButton_7.setGeometry(QRect(970, 560, 381, 61))
        self.pushButton_7.setStyleSheet("QPushButton\n"
"{\n"
"    background-color:rgb(27,27,27);\n"
"    border-radius:12px;\n"
"    color:rgb(240,240,240);\n"
"    padding-left:15px;\n"
"    border: 1px solid rgba(255, 255, 255, 50);\n"
"    font: 24pt \"Agency FB\";\n"
"}\n"
"QPushButton:focus{\n"
"    border: 1px solid rgba(99, 173, 229, 150);\n"
"}")
        self.pushButton_7.setObjectName("pushButton_7")
        self.pushButton_8 = QPushButton(Form)
        self.pushButton_8.setGeometry(QRect(950, 800, 201, 71))
        self.pushButton_8.setStyleSheet("QPushButton\n"
"{\n"
"    background-color:rgb(27,27,27);\n"
"    border-radius:12px;\n"
"    color:rgb(240,240,240);\n"
"    padding-left:15px;\n"
"    border: 1px solid rgba(255, 255, 255, 50);\n"
"    font: 24pt \"Agency FB\";\n"
"}\n"
"QPushButton:focus{\n"
"    border: 1px solid rgba(99, 173, 229, 150);\n"
"}")
        self.pushButton_8.setObjectName("pushButton_8")
        self.stackedWidget_5 = QStackedWidget(Form)
        self.stackedWidget_5.setGeometry(QRect(1160, 800, 201, 78))
        self.stackedWidget_5.setObjectName("stackedWidget_5")
        self.page_9 = QWidget()
        self.page_9.setObjectName("page_9")
        self.verticalLayout_5 = QVBoxLayout(self.page_9)
        self.verticalLayout_5.setObjectName("verticalLayout_5")
        self.pushButton_9 = QPushButton(self.page_9)
        self.pushButton_9.setMinimumSize(QSize(40, 40))
        self.pushButton_9.setStyleSheet("QPushButton\n"
"{\n"
"    background-color:rgb(27,27,27);\n"
"    border-radius:12px;\n"
"    color:rgb(240,240,240);\n"
"    padding-left:15px;\n"
"    border: 1px solid rgba(255, 255, 255, 50);\n"
"    font: 24pt \"Agency FB\";\n"
"}\n"
"QPushButton:focus{\n"
"    border: 1px solid rgba(99, 173, 229, 150);\n"
"}")
        self.pushButton_9.setObjectName("pushButton_9")
        self.verticalLayout_5.addWidget(self.pushButton_9)
        self.stackedWidget_5.addWidget(self.page_9)
        self.page_10 = QWidget()
        self.page_10.setObjectName("page_10")
        self.verticalLayout_6 = QVBoxLayout(self.page_10)
        self.verticalLayout_6.setObjectName("verticalLayout_6")
        self.pushButton_10 = QPushButton(self.page_10)
        self.pushButton_10.setMinimumSize(QSize(30, 30))
        self.pushButton_10.setStyleSheet("QPushButton\n"
 "{\n"
 "    background-color:rgb(27,27,27);\n"
 "    border-radius:12px;\n"
 "    color:rgb(240,240,240);\n"
 "    padding-left:15px;\n"
 "    border: 1px solid rgba(255, 255, 255, 50);\n"
 "    font: 24pt \"Agency FB\";\n"
 "}\n"
 "QPushButton:focus{\n"
 "    border: 1px solid rgba(99, 173, 229, 150);\n"
 "}")
        self.pushButton_10.setObjectName("pushButton_10")
        self.verticalLayout_6.addWidget(self.pushButton_10)
        self.stackedWidget_5.addWidget(self.page_10)

        self.retranslateUi(Form)
        self.stackedWidget.setCurrentIndex(1)
        self.stackedWidget_4.setCurrentIndex(1)
        self.stackedWidget_5.setCurrentIndex(1)
        # self.pushButton.clicked.connect(Form.showmain)  # type: ignore
        self.pushButton_2.clicked.connect(Form.showsub)
        # self.pushButton_3.clicked.connect(Form.logout)
        self.pushButton_4.clicked.connect(Form.singa)
        self.pushButton_5.clicked.connect(Form.chumdan)
        self.pushButton_6.clicked.connect(Form.flower)
        self.pushButton_7.clicked.connect(Form.jangduk)
        self.pushButton_8.clicked.connect(Form.exit)
        self.pushButton_9.clicked.connect(Form.logout2)
        self.pushButton_10.clicked.connect(Form.logout)
        # self.pushButton_3.clicekd.connect(Form.함수)# type: ignore
        # QtCore.QMetaObject.connectSlotsByName(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        # self.pushButton.setText("")
        self.lineEdit.setText(QCoreApplication.translate("Form", u"   \ub3c4\uc11c\uad00 \uc18c\uac1c", None))
        self.pushButton_2.setText("")
        # self.pushButton_3.setText("로그인")
        self.pushButton_4.setText("신가 도서관")
        self.pushButton_5.setText("첨단 도서관")
        self.pushButton_6.setText("이야기 꽃 도서관")
        self.pushButton_7.setText("장덕 도서관")
        self.pushButton_8.setText("종료하기")
        self.pushButton_9.setText("로그아웃")
        self.pushButton_10.setText("로그인")
        self.lineEdit_5.setText(QCoreApplication.translate("Form", u"   \ub3c4\uc11c\uad00 \uc2dc\uc124 \ubc0f \ud604\ud669", None))
        self.lineEdit_2.setText(QCoreApplication.translate("Form", u"  \ub3c4\uc11c\uad00 \ucd94\ucc9c \ub3c4\uc11c", None))
        self.lineEdit_3.setText(QCoreApplication.translate("Form", u"  \ub3c4\uc11c\uad00 \uacf5\uc9c0 \ubc0f \uc774\ubca4\ud2b8", None))

    # retranslateUi

