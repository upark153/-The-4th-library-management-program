import sys

from PySide2.QtWebEngineWidgets import QWebEnginePage, QWebEngineView
from PySide2.QtCore import QUrl
from pl import *

class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        QMainWindow.__init__(self)
        self.ui = Ui_Form()
        self.ui.setupUi(self)

        self.webEngineView = QWebEngineView()

        self.ui.verticalLayout.addWidget(self.webEngineView)

        self.webEngineView.load(QUrl("https://lib.gwangsan.go.kr/JD/contents/libByIntro"))

        self.show()

        self.webEngineView2 = QWebEngineView()

        self.ui.verticalLayout_2.addWidget(self.webEngineView2)

        self.webEngineView2.load(QUrl("https://lib.gwangsan.go.kr/JD/contents/facilitystatus"))

        self.show()

        self.webEngineView3 = QWebEngineView()

        self.ui.verticalLayout_3.addWidget(self.webEngineView3)

        self.webEngineView3.load(QUrl("https://lib.gwangsan.go.kr/JD/librarian/all"))

        self.show()

        self.webEngineView4 = QWebEngineView()

        self.ui.verticalLayout_4.addWidget(self.webEngineView4)

        self.webEngineView4.load(QUrl("https://lib.gwangsan.go.kr/JD/board/3"))

        self.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
